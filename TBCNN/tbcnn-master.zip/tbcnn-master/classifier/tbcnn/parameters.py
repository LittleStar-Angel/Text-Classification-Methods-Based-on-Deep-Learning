"""Tuning hyperparameters for the cnn network."""

LEARN_RATE = 0.001
EPOCHS = 5
CHECKPOINT_EVERY = 100

BATCH_SIZE = 1
